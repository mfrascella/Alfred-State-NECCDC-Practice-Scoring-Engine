﻿using System;
using System.Collections.Generic;
using System.Linq;
using CapstoneTestNoXML.Models;
using System.Web;
using System.Threading;

namespace CapstoneTestNoXML.Models
{
    public class Competition
    {
        private double duration;
        private int scoreMultiplier;
        private int updateTime;
        private const int MS_CONVERSION = 60000;
        //private int numServicesPerTeam;
        Team team;

        //constructor
        public Competition(double d, int s, int t /*int n*/)
        {
            this.duration = d;
            this.scoreMultiplier = s;
            this.updateTime = t;
            //this.numServicesPerTeam = n;


        }

        #region gets and sets
        public double Duration
        {
            get
            {
                return this.duration;
            }
            set
            {
                this.duration = value;
            }
        }
        public int ScoreMultiplier
        {
            get
            {
                return this.scoreMultiplier;
            }
            set
            {
                this.scoreMultiplier = value;
            }
        }
        public int UpdateTime
        {
            get
            {
                return this.updateTime;
            }
            set
            {
                this.updateTime = value;
            }
        }
        //public int NumServicesPerTeam
        //{
        //    get
        //    {
        //        return this.numServicesPerTeam;
        //    }
        //    set
        //    {
        //        this.numServicesPerTeam = value;
        //    }
        //}
        public void setTeam(string n, Service[] s)
        {
            team = new Team(n, s);
        }
        #endregion

        public void runCompetition()
        {
            //grab computer time

            //waiting x amount of time
            Thread.Sleep(MS_CONVERSION * updateTime);
            //run through pingIPs
            updateScore();

        }

        //probably going to tell them to restart to clearData
        public void clearData()
        {
            //are you sure?

        }

        public void updateScore()
        {
            for (int i = 0; i < team.Services.Length; i++)
            {
                if (team.Services[i].PingIP())
                {
                    team.OverallScore += this.scoreMultiplier;
                }
            }
        }

        /*timer
         * when (starttime - i) {
         */

    }
}