﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Web;

namespace CapstoneTestNoXML.Models
{
    public class Service
    {
        private string name;
        private string ip;
        private string status;
        Ping ping = new Ping();
        PingReply reply;

        //constructor
        public Service(string sName, string sIP)
        {
            this.name = sName;
            this.ip = sIP;
            this.status = "TimedOut";
        }

        #region gets and sets
        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }
        public string Ip
        {
            get
            {
                return this.ip;
            }
            set
            {
                this.ip = value;
            }
        }
        public string Status
        {
            get
            {
                return this.status;
            }
            set
            {
                this.status = value;
            }
        }
        #endregion

        /*maybe move the ping method in here and use it in the team to update overall score*/
        public bool PingIP()
        {
            string status;
            reply = ping.Send(this.Ip, 1000);
            status = Convert.ToString(reply.Status);
            if (status == "Success")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}