﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CapstoneTestNoXML.Models;

namespace CapstoneTestNoXML.Models
{
    public class Team
    {
        private string teamName;
        private Service[] services;
        private int overallScore;

        //constructor
        public Team(string n, Service[] s)
        {
            this.teamName = n;
            this.services = new Service[8];
            this.services = s;
            this.overallScore = 0;
        }




        #region gets and sets
        public string TeamName
        {
            get
            {
                return teamName;
            }
            set
            {
                this.teamName = value;
            }
        }
        public int OverallScore
        {
            get
            {
                return overallScore;
            }
            set
            {
                this.overallScore = value;
            }
        }

        public Service[] Services
        {
            get
            {
                return this.services;
            }
            set
            {
                this.services = value;
            }
        }
        #endregion

        //methods

        //public void updateScore(Service[] s, Competition c)
        //{
        //    for (int i = 0; i < s.Length; i++)
        //    {
        //        if (s[i].PingIP(s[i].Ip))
        //        {
        //            OverallScore += c.ScoreMultiplier;
        //        }
        //    }
        //}
    }
}