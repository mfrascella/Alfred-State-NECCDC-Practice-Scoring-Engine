﻿using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ScoringEngine.Models;
using System;

namespace ScoringEngine.DBModel
{
    public class db
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);

        public void Add_Team(Team team)
        {
            SqlCommand cmd = new SqlCommand("Add_Team", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@TeamName", team.TeamName);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void Add_Competition(Competition comp)
        {
            int tid = Get_TID();
            SqlCommand cmd = new SqlCommand("Add_Competition", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Duration", comp.Duration);
            cmd.Parameters.AddWithValue("@ScoreMultiplier", comp.ScoreMultiplier);
            cmd.Parameters.AddWithValue("@UpdateTime", comp.UpdateTime);
            cmd.Parameters.AddWithValue("@NumPulls", comp.NumPulls);
            cmd.Parameters.AddWithValue("@TeamID", tid);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            cmd.Dispose();
        }

        public void Add_Service(Service service)
        {
            int tid = Get_TID();
            SqlCommand cmd = new SqlCommand("Add_Service", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ServiceName", service.ServiceName);
            cmd.Parameters.AddWithValue("@ServiceIP", service.ServiceIP);
            cmd.Parameters.AddWithValue("@TeamID", tid);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            cmd.Dispose();
        }

        public int Get_TID()
        {
            int tid;
            SqlCommand cmd = new SqlCommand("Get_TID", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();
            tid = Convert.ToInt32(cmd.ExecuteScalar());
            conn.Close();
            cmd.Dispose();

            return tid;
        }

        public int Get_NumPulls()
        {
            int np;
            SqlCommand cmd = new SqlCommand("Get_NumPulls", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();
            np = Convert.ToInt32(cmd.ExecuteScalar());
            conn.Close();
            cmd.Dispose();

            return np;
        }

        public int Get_OverallScore()
        {
            int os;
            SqlCommand cmd = new SqlCommand("Get_OVerallScore", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();
            os = Convert.ToInt32(cmd.ExecuteScalar());
            conn.Close();
            cmd.Dispose();

            return os;
        }

        public int Get_ScoreMultiplier()
        {
            int sm;
            SqlCommand cmd = new SqlCommand("Get_ScoreMultiplier", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();
            sm = Convert.ToInt32(cmd.ExecuteScalar());
            conn.Close();
            cmd.Dispose();

            return sm;
        }

        public string Get_TName()
        {
            string tn;
            SqlCommand cmd = new SqlCommand("Get_TName", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();
            tn = Convert.ToString(cmd.ExecuteScalar());
            conn.Close();
            cmd.Dispose();

            return tn;
        }

        public int Get_UpdateTime()
        {
            int ut;
            SqlCommand cmd = new SqlCommand("Get_UpdateTime", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();
            ut = Convert.ToInt32(cmd.ExecuteScalar());
            conn.Close();
            cmd.Dispose();

            return ut;
        }
        
        public void Update_NumPulls(int np)
        {
            SqlCommand cmd = new SqlCommand("Update_NumPulls", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@NumPulls", np);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            cmd.Dispose();
        }

        public void Update_OverallScore(int os)
        {
            SqlCommand cmd = new SqlCommand("Update_OverallScore", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@OverallScore", os);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            cmd.Dispose();
        }

        public void Update_Status(Service service)
        {
            SqlCommand cmd = new SqlCommand("Update_Status", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Status", service.ServiceStatus);
            cmd.Parameters.AddWithValue("@SID", service.ServiceID);


            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            cmd.Dispose();
        }

        public void Clear_Data()
        {
            SqlCommand cmd = new SqlCommand("Clear_Data", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            cmd.Dispose();
        }

        public DataSet Get_Service_Table()
        {
            SqlCommand cmd = new SqlCommand("Get_Service_Table", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);

            cmd.Dispose();
            da.Dispose();

            return ds;
        }
    }
}