﻿using System.ComponentModel.DataAnnotations;

namespace ScoringEngine.Models
{
    public class Team
    {
        public int TeamID { get; set; }

        [Display(Name = "Team Name")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Team Name is required.")]
        public string TeamName { get; set; }

        [Display(Name = "Overall Score")]
        public int OverallScore { get; set; }
    }
}