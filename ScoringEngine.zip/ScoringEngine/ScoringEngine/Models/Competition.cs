﻿using System.ComponentModel.DataAnnotations;

namespace ScoringEngine.Models
{
    public class Competition
    {
        public string TableName = "Competition";

        public int CompID { get; set; }

        [Display(Name = "Duration (in hours as decimal)")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Duration is required.")]
        public double Duration { get; set; }

        [Display(Name = "Score Multiplier")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Score Multiplier is required.")]
        public int ScoreMultiplier { get; set; }

        [Display(Name = "Time Between Updates")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Time Between Updates is required.")]
        public int UpdateTime { get; set; }

        public int NumPulls { get; set; }

        public int TeamID { get; set; }
    }
}