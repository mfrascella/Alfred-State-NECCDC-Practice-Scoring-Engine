﻿using System.ComponentModel.DataAnnotations;

namespace ScoringEngine.Models
{
    public class Service
    {
        public string TableName = "Service";

        public int ServiceID { get; set; }

        [Display(Name = "Service Name")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Service Name is required.")]
        public string ServiceName { get; set; }

        [Display(Name = "IP Address")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Service IP is required.")]
        public string ServiceIP { get; set; }

        public string ServiceStatus { get; set; }

        public int TeamID { get; set; }
    }
}