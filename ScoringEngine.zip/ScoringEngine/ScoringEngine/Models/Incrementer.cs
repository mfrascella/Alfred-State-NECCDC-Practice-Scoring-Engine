﻿namespace ScoringEngine.Models
{
    public class Incrementer
    {
        public int num { get; set; }

        public Incrementer(int start)
        {
            num = start;
        }

        public void Increment()
        {
            num++;
        }
    }
}