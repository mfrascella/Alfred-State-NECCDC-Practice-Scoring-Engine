﻿using System;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Net.NetworkInformation;
using System.Threading;
using ScoringEngine.Models;
using System.Data;
using System.Collections.Generic;

namespace ScoringEngine.Controllers
{
    public class HomeController : Controller
    {
        DBModel.db dblayer = new DBModel.db();
        static Incrementer inc = new Incrementer(0);
        const int MS_MULT = 60000;

        public bool PingIP(string ip)
        {
            Ping ping = new Ping();
            PingReply reply;
            string status;
            reply = ping.Send(ip, 1000);
            status = Convert.ToString(reply.Status);
            if (status == "Success")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(Team t)
        {
            //insert Team into db
            dblayer.Add_Team(t);
            ViewData["msg"] = "";
            return View("AddService");
        }

        [HttpGet]
        public ActionResult AddService()
        {
            if (inc.num < 8)
            {
                ViewData["msg"] = "Service " + inc.num + " has been added";
                return View();
            }
            return View("AddCompetition");
        }

        [HttpPost]
        public ActionResult AddService(Service s)
        {
            //make increment object
            dblayer.Add_Service(s);
            inc.Increment(); 
            return RedirectToAction("AddService", "Home");
        }

        [HttpGet]
        public ActionResult AddCompetition()
        {
            return View();
        }

        [HttpPost] 
        public ActionResult AddCompetition(Competition c)
        {
            int numPulls;
            dblayer.Add_Competition(c);
            numPulls = Convert.ToInt32(c.Duration / c.UpdateTime);
            dblayer.Update_NumPulls(numPulls);
            ViewData["numPulls"] = -1;
            return View("ViewScores");
        }

       
        public ActionResult ViewScores()
        {
            int numPulls;
            double updateTime;
            int scoreMultiplier;
            bool ipUp;
            int sid;
            string sName;
            string sip;
            string sStatus;
            string tName;
            int overallScore;

            DataSet services;
            List<Service> serviceList = new List<Service>();
            Service[] sArr = new Service[8];
            
            numPulls = dblayer.Get_NumPulls();
            updateTime = dblayer.Get_UpdateTime();
            scoreMultiplier = dblayer.Get_ScoreMultiplier();
            overallScore = dblayer.Get_OverallScore();

            //Have to let this go to 0 since the first pull will just be to 
            //initialize the table in ViewScores
            while (numPulls >= 0)
            {
                numPulls--;
                dblayer.Update_NumPulls(numPulls);

                //Using the increment value to see if this is the first time visited
                //or not. If it is, inc.num should be 8 from the previous run through.
                //We want this because we want to be able to show the table on ViewScores
                //right off the bat instead of needing to wait for the next pull
                if (inc.num != 8)
                {
                    Thread.Sleep(Convert.ToInt32(updateTime * MS_MULT));
                    inc.Increment();
                }
                
                services = dblayer.Get_Service_Table();
                foreach(DataRow row in services.Tables[0].Rows)
                {
                    sid = Convert.ToInt32(row["SID"]);
                    sName = row["SName"].ToString();
                    sip = row["SIP"].ToString();
                    sStatus = row["SStatus"].ToString();
                    serviceList.Add(new Service
                    {
                        ServiceID = sid,
                        ServiceName = sName,
                        ServiceIP = sip,
                        ServiceStatus = sStatus
                    });
                    
                }
                sArr = serviceList.ToArray();

                for (int j = 0; j < 8; j++)
                {
                    ipUp = PingIP(sArr[j].ServiceIP);
                    if (ipUp)
                    {
                        sArr[j].ServiceStatus = "Up";
                        overallScore += scoreMultiplier;
                    }
                    else
                    {
                        sArr[j].ServiceStatus = "Down";
                    }
                    dblayer.Update_Status(sArr[j]);
                }

                dblayer.Update_OverallScore(overallScore);

                //toss everything into a viewdata
                tName = dblayer.Get_TName();
                ViewData["tN"] = tName;

                ViewData["s1N"] = sArr[0].ServiceName;
                ViewData["s2N"] = sArr[1].ServiceName;
                ViewData["s3N"] = sArr[2].ServiceName;
                ViewData["s4N"] = sArr[3].ServiceName;
                ViewData["s5N"] = sArr[4].ServiceName;
                ViewData["s6N"] = sArr[5].ServiceName;
                ViewData["s7N"] = sArr[6].ServiceName;
                ViewData["s8N"] = sArr[7].ServiceName;

                ViewData["s1S"] = sArr[0].ServiceStatus;
                ViewData["s2S"] = sArr[1].ServiceStatus;
                ViewData["s3S"] = sArr[2].ServiceStatus;
                ViewData["s4S"] = sArr[3].ServiceStatus;
                ViewData["s5S"] = sArr[4].ServiceStatus;
                ViewData["s6S"] = sArr[5].ServiceStatus;
                ViewData["s7S"] = sArr[6].ServiceStatus;
                ViewData["s8S"] = sArr[7].ServiceStatus;

                ViewData["score"] = overallScore;

                ViewData["numPulls"] = numPulls;

                return View();
            }

            return View();
        }

        public ActionResult ClearData()
        {
            string msg = "";

            try
            {
                dblayer.Clear_Data();
            }
            catch (SqlException se)
            {
                msg = se.Message.ToString();
            }

            if (String.IsNullOrEmpty(msg))
            {
                msg = "Data successfully deleted";
            }

            ViewData["msg"] = msg;

            return View("Index");
        }
    }
}