﻿using System;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Net.NetworkInformation;
using System.Threading;


namespace CapstoneTestNoXML.Controllers
{
    public class HomeController : Controller
    {

        public bool PingIP(string ip)
        {
            Ping ping = new Ping();
            PingReply reply;
            string status;
            reply = ping.Send(ip, 1000);
            status = Convert.ToString(reply.Status);
            if (status == "Success")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        [HttpGet]
        public ActionResult Index()
        {   
            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection coll)
        {
            Session["cs"] = @"Data Source=DESKTOP-D99K7NG\SQLEXPRESS;Initial Catalog=master";
            string cs = Session["cs"] as string;
            string sql;
            const int START_SCORE = 0;
            SqlConnection conn;
            SqlDataReader dr;
            SqlDataAdapter adpt = new SqlDataAdapter();
            SqlCommand cmd;
            int tid = 0;
            int sid = 0;
            string[] sNames;
            string[] sIPs;
            

            //grabbing information from form
            string teamName = coll[0];
            string s1Name = coll[1];
            string s1IP = coll[2];
            string s2Name = coll[3];
            string s2IP = coll[4];
            string s3Name = coll[5];
            string s3IP = coll[6];
            string s4Name = coll[7];
            string s4IP = coll[8];
            string s5Name = coll[9];
            string s5IP = coll[10];
            string s6Name = coll[11];
            string s6IP = coll[12];
            string s7Name = coll[13];
            string s7IP = coll[14];
            string s8Name = coll[15];
            string s8IP = coll[16];

            sNames = new string[8] { s1Name, s2Name, s3Name, s4Name, s5Name, s6Name, s7Name, s8Name };
            sIPs = new string[8] { s1IP, s2IP, s3IP, s4IP, s5IP, s6IP, s7IP, s8IP };

            //create db and all tables (will still work if user has tables in existence already
            sql = @"
            CREATE DATABASE ScoringEngine;

            USE ScoringEngine;
            CREATE TABLE Competition(
                CID INT NOT NULL,
                Duration DECIMAL(4, 2) NOT NULL,
                ScoreMultiplier INT NOT NULL,
                UpdateTime INT NOT NULL,
                NumPulls INT NOT NULL,
                TID INT NOT NULL,
                PRIMARY KEY(CID),
                FOREIGN KEY(TID) REFERENCES Team(TID)
            );

            CREATE TABLE Team(
                TID INT NOT NULL,
                TName VARCHAR(50) NOT NULL,
                OverallScore INT NOT NULL,
                PRIMARY KEY(TID)
            );

            CREATE TABLE Service(
                SID INT NOT NULL,
                SName VARCHAR(10) NOT NULL,
                SIP VARCHAR(15) NOT NULL,
                SStatus VARCHAR(10) NOT NULL,
                TID INT NOT NULL,
                PRIMARY KEY(SID),
                FOREIGN KEY(TID) REFERENCES Team(TID)
            );";

            conn = new SqlConnection(cs);
            adpt.InsertCommand = new SqlCommand(sql, conn);
            adpt.InsertCommand.ExecuteNonQuery();
            adpt.InsertCommand.Dispose();

            //due to dependencies, need to create team first
            //finding highest id for team
            sql = "SELECT TID FROM dbo.Team ORDER BY TID DESC;";

            cs = Session["cs"] as string;
            conn = new SqlConnection(cs);
            conn.Open();
            cmd = new SqlCommand(sql, conn);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                try
                {
                    tid = Convert.ToInt32(dr.GetValue(0));
                }
                catch (Exception e)
                {
                    tid = 0;
                }
            }

            dr.Close();
            cmd.Dispose();
            tid++;


            //insert team into db
            sql = "INSERT INTO dbo.Team(TID, TName, OverallScore) VALUES('"
                + tid + "', '" + teamName + "', '" + START_SCORE + "');";
            adpt.InsertCommand = new SqlCommand(sql, conn);
            adpt.InsertCommand.ExecuteNonQuery();
            adpt.InsertCommand.Dispose();

            //maybe put sNames and sIPs into an array to cut down on code

            //find highest SID
            sql = "SELECT SID FROM dbo.Service ORDER BY SID DESC;";
            cmd = new SqlCommand(sql, conn);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                try
                {
                    sid = Convert.ToInt32(dr.GetValue(0));
                }
                catch (Exception e)
                {
                    sid = 0;
                }
            }

            dr.Close();
            cmd.Dispose();
            sid++;

            //inserting each service into the table
            for (int i = 0; i < sNames.Length; i++)
            {
                sql = "INSERT INTO dbo.Service(SID, SName, SIP, SStatus, TID) VALUES('"
                    + sid + "', '" + sNames[i] + "', '" + sIPs[i] + "', 'Down', '" + tid + "');";
                adpt.InsertCommand = new SqlCommand(sql, conn);
                adpt.InsertCommand.ExecuteNonQuery();
                adpt.InsertCommand.Dispose();
                sid++;
            }
            conn.Close();


            ViewData["tN"] = teamName;
            ViewData["s1N"] = s1Name;
            ViewData["s2N"] = s2Name;
            ViewData["s3N"] = s3Name;
            ViewData["s4N"] = s4Name;
            ViewData["s5N"] = s5Name;
            ViewData["s6N"] = s6Name;
            ViewData["s7N"] = s7Name;
            ViewData["s8N"] = s8Name;

            ViewData["s1S"] = "Down";
            ViewData["s2S"] = "Down";
            ViewData["s3S"] = "Down";
            ViewData["s4S"] = "Down";
            ViewData["s5S"] = "Down";
            ViewData["s6S"] = "Down";
            ViewData["s7S"] = "Down";
            ViewData["s8S"] = "Down";

            return View("EditTeam");
        }

        [HttpGet]
        public ActionResult EditComp()
        {
            return View();
        }

        [HttpPost]
        public ActionResult EditComp(FormCollection collection)
        {
            double dur = Convert.ToDouble(collection[0]);
            int sm = Convert.ToInt32(collection[1]);
            int ut = Convert.ToInt32(collection[2]);

            
            string cs;
            SqlConnection conn;
            SqlDataReader dr;
            SqlCommand cmd;
            SqlDataAdapter adpt = new SqlDataAdapter();
            string sql = "";
            int cid = 0;
            int tid = 0;
            const int MINUTE_MULT = 60;
            int numOfPulls;

            numOfPulls = Convert.ToInt32((MINUTE_MULT * dur) / ut);

            //open connection
            cs = Session["cs"] as string;
            conn = new SqlConnection(cs);
            conn.Open();
            
            //insert new record into Competition table
            //in case people do not clear data, grab highest id and add one
            sql = "SELECT CID FROM dbo.Competition ORDER BY CID DESC;";
            cmd = new SqlCommand(sql, conn);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                try
                {
                    cid = Convert.ToInt32(dr.GetValue(0));
                }
                catch (Exception e)
                {
                    cid = 0;
                }
            }

            dr.Close();
            cmd.Dispose();
            //add one to id to make it the next one up
            cid++;

            //users need to create a new team each time, so the id of the current team will be the largest
            sql = "SELECT TID FROM dbo.Team ORDER BY TID DESC;";
            cmd = new SqlCommand(sql, conn);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                tid = Convert.ToInt32(dr.GetValue(0));
                break;
            }

            dr.Close();
            cmd.Dispose();
            //insert record into Competition
            sql = "INSERT INTO dbo.Competition(CID, Duration, ScoreMultiplier, UpdateTime, NumPulls, TID) VALUES('"
                + cid + "', '" + dur + "', '" + sm + "', '" + ut + "', '" + numOfPulls + "', '" + tid + "');";
            adpt.InsertCommand = new SqlCommand(sql, conn);
            adpt.InsertCommand.ExecuteNonQuery();
            adpt.InsertCommand.Dispose();

            conn.Close();

            return View("ViewScores");
        }

        public ActionResult ViewScores()
        {

            string cs;
            SqlConnection conn;
            SqlDataReader dr;
            SqlCommand cmd;
            SqlDataAdapter adpt = new SqlDataAdapter();
            string sql = "";
            int tid = 0;
            int i = 0;
            int k = 0;
            int scoreToAdd = 0;
            string[] ips = new string[8];
            string[] statuses = new string[8];
            string[] sNames = new string[8];
            int sm = 0;
            int os = 0;
            string tName = "";
            int numPulls = 0;
            int updateTime = 0;
            int cid = 0;
            const int MS_MULT = 60000;
            
            cs = Session["cs"] as string;
            conn = new SqlConnection(cs);
            conn.Open();

            //grab numPulls
            sql = "SELECT NumPulls FROM dbo.Competition;";
            cmd = new SqlCommand(sql, conn);
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                numPulls = Convert.ToInt32(dr.GetValue(0));
                break;
            }
            dr.Close();
            cmd.Dispose();

            while (numPulls != 0)
            {
                sql = "SELECT CID FROM dbo.Competition ORDER BY CID DESC;";
                cmd = new SqlCommand(sql, conn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cid = Convert.ToInt32(dr.GetValue(0));
                    break;
                }

                numPulls--;
                sql = "UPDATE Competition SET NumPulls = " + numPulls + "WHERE CID = " + cid + ";";
                adpt.InsertCommand = new SqlCommand(sql, conn);
                adpt.InsertCommand.ExecuteNonQuery();
                adpt.InsertCommand.Dispose();

                //grab update time
                sql = "SELECT UpdateTime FROM dbo.Competition;";
                cmd = new SqlCommand(sql, conn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    updateTime = Convert.ToInt32(dr.GetValue(0));
                    break;
                }
                dr.Close();
                cmd.Dispose();

                Thread.Sleep(updateTime * MS_MULT);

                //grab ips
                sql = "SELECT SIP FROM dbo.Service;";
                cmd = new SqlCommand(sql, conn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    ips[i] = dr.GetValue(0).ToString();
                    i++;
                }
                dr.Close();
                cmd.Dispose();

                //grab scoreMultiplier
                sql = "SELECT ScoreMultiplier FROM dbo.Competition;";
                cmd = new SqlCommand(sql, conn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    sm = Convert.ToInt32(dr.GetValue(0));
                    break;
                }
                dr.Close();
                cmd.Dispose();


                bool ipUp;
                for (int j = 0; j < 8; i++)
                {
                    ipUp = PingIP(ips[j]);
                    if (ipUp)
                    {
                        statuses[j] = "Up";
                        scoreToAdd += sm;
                    }
                    else
                    {
                        statuses[j] = "Down";
                    }

                    sql = "UPDATE Service SET SStatus = '" + statuses[j]
                        + "' WHERE SID = " + (i + 1) + ";";
                    adpt.InsertCommand = new SqlCommand(sql, conn);
                    adpt.InsertCommand.ExecuteNonQuery();
                    adpt.InsertCommand.Dispose();
                    
                }

                //getting TID
                sql = "SELECT TID FROM dbo.Team ORDER BY TID DESC;";
                cmd = new SqlCommand(sql, conn);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    tid = Convert.ToInt32(dr.GetValue(0));
                    break;
                }

                dr.Close();
                cmd.Dispose();

                //grabbing overallScore to add the points to be added to
                sql = "SELECT OverallScore FROM Team WHERE TID = " + tid + ";";
                cmd = new SqlCommand(sql, conn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    os = Convert.ToInt32(dr.GetValue(0));
                    break;
                }
                dr.Close();
                cmd.Dispose();

                os += scoreToAdd;

                //updating the score in db
                sql = "UPDATE Team SET OverallScore = " + os + " WHERE TID = " + tid + ";";
                adpt.InsertCommand = new SqlCommand(sql, conn);
                adpt.InsertCommand.ExecuteNonQuery();
                adpt.InsertCommand.Dispose();

                //grabbing service names to put in ViewDatas
                sql = "SELECT SName FROM dbo.Service;";
                cmd = new SqlCommand(sql, conn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    sNames[k] = dr.GetValue(0).ToString();
                    k++;
                }
                dr.Close();
                cmd.Dispose();

                //grabbing TName to put in ViewData
                sql = "SELECT TName FROM dbo.Team WHERE TID = " + tid + ";";
                cmd = new SqlCommand(sql, conn);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    tName = dr.GetValue(0).ToString();
                    break;
                }
                dr.Close();
                cmd.Dispose();

                //putting everything that needs to be in a ViewData in there
                ViewData["s1S"] = statuses[0];
                ViewData["s2S"] = statuses[1];
                ViewData["s3S"] = statuses[2];
                ViewData["s4S"] = statuses[3];
                ViewData["s5S"] = statuses[4];
                ViewData["s6S"] = statuses[5];
                ViewData["s7S"] = statuses[6];
                ViewData["s8S"] = statuses[7];

                ViewData["s1N"] = sNames[0];
                ViewData["s2N"] = sNames[1];
                ViewData["s3N"] = sNames[2];
                ViewData["s4N"] = sNames[3];
                ViewData["s5N"] = sNames[4];
                ViewData["s6N"] = sNames[5];
                ViewData["s7N"] = sNames[6];
                ViewData["s8N"] = sNames[7];

                ViewData["score"] = os;

                ViewData["tN"] = tName;

                ViewData["numPulls"] = numPulls;

                conn.Close();
                return View();
            }


            ViewData["numPulls"] = numPulls;
            return View();
        }

        public ActionResult ClearData()
        {
            //putting breakpoint in here because i need to know 
            //when it is actually going in here if it is at all
            string cs;
            string msg = "";
            SqlConnection conn;
            SqlDataAdapter adpt = new SqlDataAdapter();
            string sql = "";

            cs = Session["cs"] as string;
            conn = new SqlConnection(cs);
            conn.Open();

            sql = "DROP DATABASE ScoringEngine;";
            try
            {
                adpt.DeleteCommand = new SqlCommand(sql, conn);
                adpt.DeleteCommand.ExecuteNonQuery();
            }
            catch (SqlException se)
            {
                msg = se.Message.ToString();
            }
            finally
            {
                adpt.DeleteCommand.Dispose();
                conn.Close();
            }

            if (String.IsNullOrEmpty(msg))
            {
                msg = "Data successfully deleted";
            }

            Response.Redirect("Index.cshtml");

            
            return View();
        }
    }
}